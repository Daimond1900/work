package com.winksoft.android.yzjycy.fragment;

import com.winksoft.android.yzjycy.newentity.User;

import android.support.v4.app.Fragment;

public class BaseFragment extends Fragment{

	protected User user;
	
	@Override
	public void onResume() {
		super.onResume();
		
	}
}
