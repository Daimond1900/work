package com.winksoft.android.yzjycy.IBase;

public interface IConfirmDialog {
	public void onConfirm();
	public void onCancel();
}
