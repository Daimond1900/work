package com.test.test_print.print;

import java.util.HashMap;
import java.util.Map;

import com.test.test_print.R;
import com.test.test_print.base.BaseActivity;
import com.test.test_print.print.info.CallBackListener;
import com.test.test_print.print.info.YFApp;
import com.yifengcom.yfpos.model.PrintType;

import android.app.AlertDialog;
import android.os.Bundle;
import android.os.RemoteException;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class printActivity extends BaseActivity implements OnClickListener {
	private Button printTest;
	private Map<String,String> settingMap;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_signout);
		setTitle("打印测试");
		printTest = (Button) super.findViewById(R.id.printTest);
		printTest.setOnClickListener(this);
	}


	private boolean printReceipt() {
		boolean flage = false;
			Map<String, String> map = new HashMap<String, String>();
			map.put("title1", "12312421423523124");
			map.put("title2", "1111111");
			map.put("stel", "0514-88888888");
			map.put("mno", "0101");
			map.put("tel", "0514-87777777");
			map.put("cno", "12312312");
			map.put("tno", "A·123");
			map.put("up", "￥8.00");
			map.put("mil", "1000m");
			map.put("wait", "1");
			map.put("sum", "￥8.00");
			try {
				YFApp.getApp().iService.onPrint(getPrintBody(map), mCallBack);
				flage = true;
			} catch (RemoteException e) {
				e.printStackTrace();
				showToast("打印异常");
			} catch (Exception e) {
				e.printStackTrace();
				showToast("打印异常");
			}
		return flage;
	}

	protected CallBackListener mCallBack = new CallBackListener() {
		@Override
		public void onError(final int errorCode, final String errorMessage) throws RemoteException {

			runOnUiThread(new Runnable() {
				public void run() {
					new AlertDialog.Builder(printActivity.this).setTitle("提示")
							.setMessage("操作失败，返回码:" + errorCode + " 信息:" + errorMessage).setPositiveButton("确定", null)
							.show();
				}
			});
		}

		@Override
		public void onTimeout() throws RemoteException {
			runOnUiThread(new Runnable() {
				public void run() {
					new AlertDialog.Builder(printActivity.this).setTitle("错误").setMessage("打印超时")
							.setPositiveButton("确定", null).show();
				}
			});
		}

		@Override
		public void onResultSuccess(final int ntype) throws RemoteException {
			runOnUiThread(new Runnable() {
				public void run() {
					if (ntype != 0) {
					}
					showToast(PrintType.convert(ntype).getMesssage());
				}
			});
		}

		@Override
		public void onTradeCancel() throws RemoteException {
			runOnUiThread(new Runnable() {
				public void run() {
					new AlertDialog.Builder(printActivity.this).setTitle("错误").setMessage("取消打印")
							.setPositiveButton("确定", null).show();
				}
			});
		}
	};


	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.printTest:
			printReceipt();
			break;
		default:
			break;
		}
	}
}
